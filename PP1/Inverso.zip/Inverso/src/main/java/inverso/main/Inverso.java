package inverso.main;

import java.util.Scanner;

public class Inverso {

    int conversion(int num, int inv) {
        if (num > 0) {
            return conversion(num / 10, num % 10 + inv * 10);
        } else {
            return inv;
        }
    }

    public static void main(String[] args) {
        Inverso numInverso = new Inverso();
        Scanner sc = new Scanner(System.in);
        int num, inv = 0;
        System.out.println("Ingrese un número: ");
        num = sc.nextInt();
        System.out.println("El número ingresado fue: " + num + " y el inverso es: " + numInverso.conversion(num, inv));
    }

}
